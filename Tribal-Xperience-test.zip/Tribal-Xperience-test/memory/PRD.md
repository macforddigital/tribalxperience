# Tribal Xperience - PRD

## Original Problem Statement
Build a premium, bold, cinematic, high-adrenaline website for Tribal Xperience — an Adventure / Off-Road & Motorsport Experience Venue. Dark immersive theme with red and gold accents. Single-page landing with booking functionality.

## Architecture
- **Frontend**: React + Tailwind CSS + Shadcn UI + Framer Motion
- **Backend**: FastAPI + Motor (MongoDB async driver)
- **Database**: MongoDB
- **Styling**: Dark theme (#111111), Red (#D12828), Gold (#F2C94C)
- **Fonts**: Anton (headings), Exo 2 (body), Oswald (accents)

## User Personas
- Motorsport enthusiasts (18-45)
- Adventure seekers
- Event organisers / Corporate teams
- Car/Bike clubs
- Young adults seeking adrenaline experiences

## Core Requirements
- Cinematic hero section with particle effects
- Section navigation (About, Experiences, Events, Gallery, Contact)
- Experience cards with 3D hover effects
- Animated stat counters
- Image gallery with spotlight hover
- Testimonials slider
- Booking modal with form (name, email, phone, experience type, date, message)
- Responsive design (mobile-first)

## What's Been Implemented (Dec 2025)
- Full single-page landing site with 9 sections
- Backend API: POST/GET /api/bookings, POST /api/contact
- Booking modal with Calendar date picker and Select dropdown
- Sticky glassmorphism navbar with mobile menu
- Framer Motion scroll-triggered animations
- Animated stat counters with IntersectionObserver
- Gallery with spotlight hover effects
- Testimonials auto-rotating slider
- Premium footer with large watermark text

## Prioritized Backlog
### P0 (Complete)
- All core sections implemented and tested

### P1 (Next)
- Admin dashboard for viewing/managing bookings
- Email notifications on new bookings
- Real image assets from client

### P2 (Future)
- Online payment integration (deposits)
- Event calendar with availability
- User accounts / booking history
- Blog/news section
- SEO meta tags optimization
