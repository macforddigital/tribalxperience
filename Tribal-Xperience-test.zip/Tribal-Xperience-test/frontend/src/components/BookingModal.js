import { useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import { format } from "date-fns";
import { CalendarIcon, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const experienceTypes = [
  "Off-Road Tracks",
  "Bike Events",
  "4x4 Experiences",
  "Test Drive Events",
  "Corporate Booking",
  "Club Event",
];

export default function BookingModal({ open, onOpenChange }) {
  const [loading, setLoading] = useState(false);
  const [date, setDate] = useState(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    experience_type: "",
    message: "",
  });

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone || !form.experience_type || !date) {
      toast.error("Please fill in all required fields");
      return;
    }

    setLoading(true);
    try {
      await axios.post(`${API}/bookings`, {
        ...form,
        preferred_date: format(date, "yyyy-MM-dd"),
      });
      toast.success("Booking submitted! We'll contact you shortly.");
      setForm({ name: "", email: "", phone: "", experience_type: "", message: "" });
      setDate(null);
      onOpenChange(false);
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        data-testid="booking-modal"
        className="bg-[#1A1A1A] border-white/10 text-white max-w-lg max-h-[90vh] overflow-y-auto"
      >
        <DialogHeader>
          <DialogTitle className="font-anton text-2xl tracking-wider text-white">
            BOOK YOUR <span className="text-[#D12828]">ADVENTURE</span>
          </DialogTitle>
          <DialogDescription className="font-exo text-gray-500 text-sm">
            Fill in the details below and we'll get back to you within 24 hours.
          </DialogDescription>
        </DialogHeader>

        <form
          data-testid="booking-form"
          onSubmit={handleSubmit}
          className="space-y-5 mt-4"
        >
          {/* Name */}
          <div className="space-y-2">
            <Label className="font-oswald text-xs tracking-widest text-gray-400 uppercase">
              Full Name *
            </Label>
            <Input
              data-testid="booking-name-input"
              placeholder="John Doe"
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className="bg-white/5 border-white/10 focus:border-[#D12828] text-white placeholder-gray-600 rounded-none h-12"
            />
          </div>

          {/* Email */}
          <div className="space-y-2">
            <Label className="font-oswald text-xs tracking-widest text-gray-400 uppercase">
              Email Address *
            </Label>
            <Input
              data-testid="booking-email-input"
              type="email"
              placeholder="john@example.com"
              value={form.email}
              onChange={(e) => handleChange("email", e.target.value)}
              className="bg-white/5 border-white/10 focus:border-[#D12828] text-white placeholder-gray-600 rounded-none h-12"
            />
          </div>

          {/* Phone */}
          <div className="space-y-2">
            <Label className="font-oswald text-xs tracking-widest text-gray-400 uppercase">
              Phone Number *
            </Label>
            <Input
              data-testid="booking-phone-input"
              type="tel"
              placeholder="+27 82 123 4567"
              value={form.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              className="bg-white/5 border-white/10 focus:border-[#D12828] text-white placeholder-gray-600 rounded-none h-12"
            />
          </div>

          {/* Experience Type */}
          <div className="space-y-2">
            <Label className="font-oswald text-xs tracking-widest text-gray-400 uppercase">
              Experience Type *
            </Label>
            <Select
              value={form.experience_type}
              onValueChange={(val) => handleChange("experience_type", val)}
            >
              <SelectTrigger
                data-testid="booking-experience-select"
                className="bg-white/5 border-white/10 focus:border-[#D12828] text-white rounded-none h-12"
              >
                <SelectValue placeholder="Select an experience" />
              </SelectTrigger>
              <SelectContent className="bg-[#1A1A1A] border-white/10">
                {experienceTypes.map((type) => (
                  <SelectItem
                    key={type}
                    value={type}
                    className="text-white focus:bg-[#D12828]/20 focus:text-white"
                  >
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Preferred Date */}
          <div className="space-y-2">
            <Label className="font-oswald text-xs tracking-widest text-gray-400 uppercase">
              Preferred Date *
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <button
                  type="button"
                  data-testid="booking-date-picker"
                  className="flex items-center justify-between w-full h-12 px-3 bg-white/5 border border-white/10 text-sm hover:border-[#D12828]/50 transition-colors"
                >
                  <span className={date ? "text-white" : "text-gray-600"}>
                    {date ? format(date, "PPP") : "Pick a date"}
                  </span>
                  <CalendarIcon size={16} className="text-gray-500" />
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-[#1A1A1A] border-white/10" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(d) => d < new Date()}
                  className="bg-[#1A1A1A] text-white"
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label className="font-oswald text-xs tracking-widest text-gray-400 uppercase">
              Message (Optional)
            </Label>
            <textarea
              data-testid="booking-message-input"
              placeholder="Any special requests or group size..."
              value={form.message}
              onChange={(e) => handleChange("message", e.target.value)}
              rows={3}
              className="w-full bg-white/5 border border-white/10 focus:border-[#D12828] text-white placeholder-gray-600 rounded-none p-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-[#D12828]"
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            data-testid="booking-submit-btn"
            disabled={loading}
            className="w-full font-oswald text-sm tracking-widest bg-[#D12828] text-white py-4 hover:bg-red-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                SUBMITTING...
              </>
            ) : (
              "SUBMIT BOOKING"
            )}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
