import { motion } from "framer-motion";
import { Mountain, Bike, Truck, Gauge } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const experiences = [
  {
    icon: Mountain,
    title: "OFF-ROAD TRACKS",
    desc: "Conquer rugged terrain on our purpose-built off-road circuits. Mud, rocks, and extreme inclines await the brave.",
    image:
      "https://images.pexels.com/photos/18086894/pexels-photo-18086894.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    tag: "POPULAR",
  },
  {
    icon: Bike,
    title: "BIKE EVENTS",
    desc: "High-octane motocross and enduro events for two-wheel warriors. Race against the clock or go head-to-head.",
    image:
      "https://images.pexels.com/photos/34190078/pexels-photo-34190078.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    tag: "ADRENALINE",
  },
  {
    icon: Truck,
    title: "4X4 EXPERIENCES",
    desc: "Take command of powerful 4x4 machines through technical trails designed to test skill, nerve, and machine.",
    image:
      "https://images.unsplash.com/photo-1762134058105-ecde16a0ba60?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzV8MHwxfHNlYXJjaHw0fHxvZmYtcm9hZCUyMDR4NCUyMGFkdmVudHVyZSUyMGRpcnQlMjB0cmFja3xlbnwwfHx8fDE3NzE5MjM3MTV8MA&ixlib=rb-4.1.0&q=85",
    tag: "FEATURED",
  },
  {
    icon: Gauge,
    title: "TEST DRIVE EVENTS",
    desc: "Experience the latest vehicles on our performance tracks. Feel the power, precision, and pure driving thrill.",
    image:
      "https://images.pexels.com/photos/14909157/pexels-photo-14909157.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    tag: "NEW",
  },
];

export default function ExperiencesSection() {
  return (
    <section
      id="experiences"
      data-testid="experiences-section"
      className="relative py-20 md:py-32 bg-[#0D0D0D]"
    >
      {/* Subtle top gradient */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#111111] to-transparent" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
          className="text-center mb-16"
        >
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-4"
          >
            What We Offer
          </motion.p>
          <motion.h2
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-anton text-4xl sm:text-5xl lg:text-6xl uppercase tracking-wide"
          >
            THE <span className="text-[#D12828]">EXPERIENCES</span>
          </motion.h2>
        </motion.div>

        {/* Experience Cards Grid */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.12 } },
          }}
          className="grid md:grid-cols-2 gap-6"
        >
          {experiences.map((exp, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              data-testid={`experience-card-${i}`}
              className="group relative overflow-hidden bg-white/[0.03] border border-white/10 hover:border-[#D12828]/50 transition-all duration-500 backdrop-blur-sm card-3d glow-border-hover"
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={exp.image}
                  alt={exp.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/40 to-transparent" />

                {/* Tag */}
                <span className="absolute top-4 right-4 font-oswald text-xs tracking-widest bg-[#F2C94C] text-black px-3 py-1 font-semibold">
                  {exp.tag}
                </span>
              </div>

              {/* Content */}
              <div className="p-6 relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-[#D12828]/20 border border-[#D12828]/30">
                    <exp.icon size={20} className="text-[#D12828]" />
                  </div>
                  <h3 className="font-anton text-xl tracking-wider">
                    {exp.title}
                  </h3>
                </div>
                <p className="font-exo text-sm text-gray-500 leading-relaxed">
                  {exp.desc}
                </p>

                {/* Hover accent line */}
                <div className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-[#D12828] to-[#F2C94C] transition-all duration-500 group-hover:w-full" />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
