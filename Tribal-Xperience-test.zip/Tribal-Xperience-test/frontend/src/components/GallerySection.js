import { useState } from "react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const galleryImages = [
  {
    src: "https://images.pexels.com/photos/13460682/pexels-photo-13460682.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Racing helmet close-up",
    span: "md:col-span-2 md:row-span-2",
  },
  {
    src: "https://images.pexels.com/photos/33626709/pexels-photo-33626709.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Drift action shot",
    span: "",
  },
  {
    src: "https://images.pexels.com/photos/14909157/pexels-photo-14909157.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Rally race",
    span: "",
  },
  {
    src: "https://images.unsplash.com/photo-1734410117891-bd6b5c61177e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzV8MHwxfHNlYXJjaHwyfHxvZmYtcm9hZCUyMDR4NCUyMGFkdmVudHVyZSUyMGRpcnQlMjB0cmFja3xlbnwwfHx8fDE3NzE5MjM3MTV8MA&ixlib=rb-4.1.0&q=85",
    alt: "Quad bike desert jump",
    span: "",
  },
  {
    src: "https://images.pexels.com/photos/18086894/pexels-photo-18086894.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Off-road track",
    span: "md:col-span-2",
  },
  {
    src: "https://images.pexels.com/photos/34190078/pexels-photo-34190078.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Motocross action",
    span: "",
  },
];

function GalleryItem({ image, index }) {
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMousePos({ x, y });
  };

  return (
    <motion.div
      variants={fadeUp}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      data-testid={`gallery-image-${index}`}
      className={`group relative overflow-hidden cursor-pointer ${image.span}`}
      onMouseMove={handleMouseMove}
      style={{
        "--mouse-x": `${mousePos.x}%`,
        "--mouse-y": `${mousePos.y}%`,
      }}
    >
      <div className="relative h-64 md:h-full min-h-[200px] overflow-hidden spotlight-hover">
        <img
          src={image.src}
          alt={image.alt}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {/* Cinematic overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 group-hover:from-black/40 transition-all duration-500" />

        {/* Caption on hover */}
        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
          <p className="font-oswald text-xs tracking-widest text-white/80 uppercase">
            {image.alt}
          </p>
        </div>

        {/* Corner accent */}
        <div className="absolute top-3 left-3 w-6 h-6 border-t border-l border-[#D12828]/0 group-hover:border-[#D12828]/60 transition-all duration-500" />
        <div className="absolute bottom-3 right-3 w-6 h-6 border-b border-r border-[#D12828]/0 group-hover:border-[#D12828]/60 transition-all duration-500" />
      </div>
    </motion.div>
  );
}

export default function GallerySection() {
  return (
    <section
      id="gallery"
      data-testid="gallery-section"
      className="relative py-20 md:py-32 bg-[#111111]"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
          className="text-center mb-16"
        >
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-4"
          >
            In The Dirt
          </motion.p>
          <motion.h2
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-anton text-4xl sm:text-5xl lg:text-6xl uppercase tracking-wide"
          >
            ACTION <span className="text-[#D12828]">MOMENTS</span>
          </motion.h2>
        </motion.div>

        {/* Gallery Grid */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.08 } },
          }}
          className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3"
        >
          {galleryImages.map((image, i) => (
            <GalleryItem key={i} image={image} index={i} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
