import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    name: "JAKE MORRISON",
    role: "Car Club Organiser",
    text: "Tribal Xperience gave our club the best day out we've ever had. The tracks are insane, the vibe is electric, and the team made everything seamless. We're coming back every month.",
  },
  {
    name: "SARAH VAN DER BERG",
    role: "Corporate Events Manager",
    text: "We booked a corporate team-building day and it exceeded every expectation. Our team was buzzing for weeks. The perfect blend of adrenaline and professionalism.",
  },
  {
    name: "THABO NKOSI",
    role: "Motocross Rider",
    text: "As a competitive rider, I've been on tracks all over SA. Tribal Xperience is built different — the terrain, the challenges, the atmosphere. It's a true arena for riders.",
  },
  {
    name: "EMMA BRADLEY",
    role: "Adventure Tourist",
    text: "We came for a weekend getaway and left as part of the tribe. The 4x4 experience was phenomenal. Can't wait to bring more friends next time.",
  },
];

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0);
  const total = testimonials.length;

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % total);
  }, [total]);

  const prev = () => {
    setCurrent((prev) => (prev - 1 + total) % total);
  };

  useEffect(() => {
    const timer = setInterval(next, 6000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <section
      data-testid="testimonials-section"
      className="relative py-20 md:py-32 bg-[#0D0D0D] overflow-hidden"
    >
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-[#D12828]/5 blur-[200px]" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-4">
            The Tribe Speaks
          </p>
          <h2 className="font-anton text-4xl sm:text-5xl lg:text-6xl uppercase tracking-wide">
            COMMUNITY <span className="text-[#D12828]">VOICES</span>
          </h2>
        </motion.div>

        {/* Testimonial Slider */}
        <div className="max-w-4xl mx-auto">
          <div className="relative min-h-[250px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                data-testid={`testimonial-card-${current}`}
                className="p-8 md:p-12 bg-white/[0.03] border border-white/10 backdrop-blur-sm relative"
              >
                <Quote
                  size={40}
                  className="text-[#D12828]/30 absolute top-6 left-6"
                />
                <p className="font-exo text-base md:text-lg text-gray-300 leading-relaxed mb-8 relative z-10 pl-8">
                  "{testimonials[current].text}"
                </p>
                <div className="flex items-center gap-4 pl-8">
                  <div className="w-1 h-10 bg-[#D12828]" />
                  <div>
                    <p className="font-anton text-lg tracking-wider">
                      {testimonials[current].name}
                    </p>
                    <p className="font-oswald text-xs tracking-widest text-[#F2C94C]">
                      {testimonials[current].role}
                    </p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-6 mt-8">
            <button
              data-testid="testimonial-prev-btn"
              onClick={prev}
              className="w-12 h-12 flex items-center justify-center border border-white/10 hover:border-[#D12828] hover:bg-[#D12828]/10 transition-all duration-300"
            >
              <ChevronLeft size={20} />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`w-2 h-2 transition-all duration-300 ${
                    i === current
                      ? "bg-[#D12828] w-6"
                      : "bg-white/20 hover:bg-white/40"
                  }`}
                />
              ))}
            </div>

            <button
              data-testid="testimonial-next-btn"
              onClick={next}
              className="w-12 h-12 flex items-center justify-center border border-white/10 hover:border-[#D12828] hover:bg-[#D12828]/10 transition-all duration-300"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
