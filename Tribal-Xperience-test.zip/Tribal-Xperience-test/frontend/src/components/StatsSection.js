import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Route, CalendarCheck, Users, Building2 } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const stats = [
  { icon: Route, value: 12, suffix: "+", label: "TRACKS BUILT" },
  { icon: CalendarCheck, value: 500, suffix: "+", label: "EVENTS HOSTED" },
  { icon: Users, value: 25000, suffix: "+", label: "RIDERS SERVED", display: "25K" },
  { icon: Building2, value: 150, suffix: "+", label: "CORPORATE EVENTS" },
];

function useCountUp(end, duration = 2000) {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted) {
          setHasStarted(true);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;
    let start = 0;
    const step = end / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [hasStarted, end, duration]);

  return { count, ref };
}

function StatCard({ stat, index }) {
  const displayValue = stat.display || null;
  const { count, ref } = useCountUp(
    displayValue ? parseInt(displayValue) : stat.value,
    2000
  );

  const formatCount = () => {
    if (displayValue) {
      return count >= parseInt(displayValue)
        ? displayValue
        : `${count}`;
    }
    return count.toLocaleString();
  };

  return (
    <motion.div
      ref={ref}
      variants={fadeUp}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      data-testid={`stat-card-${index}`}
      className="relative flex flex-col items-center justify-center p-8 md:p-10 bg-gradient-to-br from-white/[0.04] to-transparent border-t border-white/10 group animate-shimmer"
    >
      {/* Orbit glow */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border border-[#F2C94C]/10" />
      </div>

      <stat.icon
        size={28}
        className="text-[#D12828] mb-4 group-hover:text-[#F2C94C] transition-colors duration-500"
      />
      <span className="font-anton text-4xl md:text-5xl text-[#F2C94C] tracking-wide mb-2">
        {formatCount()}
        {stat.suffix}
      </span>
      <span className="font-oswald text-xs tracking-[0.2em] text-gray-500">
        {stat.label}
      </span>
    </motion.div>
  );
}

export default function StatsSection() {
  return (
    <section
      data-testid="stats-section"
      className="relative py-20 md:py-28 bg-[#0A0A0A] overflow-hidden"
    >
      {/* Background spotlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#D12828]/5 blur-[200px]" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
          className="text-center mb-16"
        >
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-4"
          >
            By The Numbers
          </motion.p>
          <motion.h2
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-anton text-4xl sm:text-5xl lg:text-6xl uppercase tracking-wide"
          >
            OUR <span className="text-[#D12828]">LEGACY</span>
          </motion.h2>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.12 } },
          }}
          className="grid grid-cols-2 lg:grid-cols-4"
        >
          {stats.map((stat, i) => (
            <StatCard key={i} stat={stat} index={i} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
