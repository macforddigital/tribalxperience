import { motion } from "framer-motion";
import { Target, Users, Trophy } from "lucide-react";

const ABOUT_IMG =
  "https://images.unsplash.com/photo-1767566168964-e7ae816286a0?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzV8MHwxfHNlYXJjaHwzfHxvZmYtcm9hZCUyMDR4NCUyMGFkdmVudHVyZSUyMGRpcnQlMjB0cmFja3xlbnwwfHx8fDE3NzE5MjM3MTV8MA&ixlib=rb-4.1.0&q=85";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const milestones = [
  {
    icon: Target,
    title: "ADVENTURE",
    desc: "Designed tracks that push boundaries and test courage.",
  },
  {
    icon: Users,
    title: "COMMUNITY",
    desc: "A tribe of riders, drivers, and thrill-seekers united.",
  },
  {
    icon: Trophy,
    title: "COMPETITION",
    desc: "Competitive events that forge champions and legends.",
  },
];

export default function AboutSection() {
  return (
    <section
      id="about"
      data-testid="about-section"
      className="relative py-20 md:py-32 bg-[#111111]"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeUp}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            <div className="relative overflow-hidden">
              <img
                src={ABOUT_IMG}
                alt="Off-road adventure"
                data-testid="about-image"
                className="w-full h-[400px] md:h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#D12828] to-[#F2C94C]" />
            </div>
            {/* Decorative corner */}
            <div className="absolute -top-4 -left-4 w-16 h-16 border-t-2 border-l-2 border-[#F2C94C]/50" />
          </motion.div>

          {/* Text */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={{
              hidden: { opacity: 0 },
              visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
            }}
          >
            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.6 }}
              className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-4"
            >
              Our Story
            </motion.p>
            <motion.h2
              variants={fadeUp}
              transition={{ duration: 0.6 }}
              data-testid="about-heading"
              className="font-anton text-4xl sm:text-5xl lg:text-6xl uppercase tracking-wide mb-6"
            >
              BORN FROM
              <br />
              <span className="text-[#D12828]">DUST & FIRE</span>
            </motion.h2>
            <motion.div
              variants={fadeUp}
              transition={{ duration: 0.6 }}
              className="w-16 h-[3px] bg-[#F2C94C] mb-8"
            />
            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.6 }}
              data-testid="about-description"
              className="font-exo text-gray-400 text-base leading-relaxed mb-6"
            >
              Tribal Xperience was forged from a passion for raw, untamed
              adventure. We built South Africa's most intense off-road and
              motorsport venue where adrenaline meets community. Every track
              tells a story, every event builds a legend.
            </motion.p>
            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.6 }}
              className="font-exo text-gray-500 text-base leading-relaxed"
            >
              From weekend warriors to corporate teams, from solo riders to
              massive club meetups — this is where the tribe gathers to push
              limits and make memories.
            </motion.p>
          </motion.div>
        </div>

        {/* Milestone Cards */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
          className="grid md:grid-cols-3 gap-6 mt-16 md:mt-24"
        >
          {milestones.map((m, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              data-testid={`milestone-card-${i}`}
              className="group p-8 bg-white/[0.03] border border-white/10 hover:border-[#D12828]/40 transition-all duration-500 glow-border-hover"
            >
              <m.icon
                size={32}
                className="text-[#F2C94C] mb-4 group-hover:scale-110 transition-transform duration-300"
              />
              <h3 className="font-anton text-xl tracking-wider mb-3">{m.title}</h3>
              <p className="font-exo text-sm text-gray-500 leading-relaxed">
                {m.desc}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
