import { motion } from "framer-motion";
import { ChevronDown, Play } from "lucide-react";

const HERO_BG =
  "https://images.pexels.com/photos/14507724/pexels-photo-14507724.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const Particle = ({ delay, left, size, duration }) => (
  <div
    className="absolute rounded-full bg-white/20"
    style={{
      left: `${left}%`,
      width: size,
      height: size,
      bottom: "-10px",
      animation: `float-up ${duration}s ease-in-out ${delay}s infinite`,
    }}
  />
);

export default function HeroSection({ onBookingOpen }) {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    delay: Math.random() * 8,
    left: Math.random() * 100,
    size: `${Math.random() * 4 + 1}px`,
    duration: Math.random() * 6 + 8,
  }));

  return (
    <section
      id="hero"
      data-testid="hero-section"
      className="relative min-h-screen flex items-center justify-center overflow-hidden grain-overlay"
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${HERO_BG})` }}
      />

      {/* Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-[#111111]" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-transparent to-black/70" />

      {/* Spotlight */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[#D12828]/10 blur-[150px]" />

      {/* Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map((p, i) => (
          <Particle key={i} {...p} />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center pt-20">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.15 } },
          }}
        >
          {/* Tagline */}
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="font-oswald text-sm md:text-base tracking-[0.3em] text-[#F2C94C] uppercase mb-6"
            data-testid="hero-tagline"
          >
            Off-Road &bull; Motorsport &bull; Adventure
          </motion.p>

          {/* Headline */}
          <motion.h1
            variants={fadeUp}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="font-anton text-6xl sm:text-7xl md:text-8xl lg:text-9xl leading-[0.9] tracking-wide uppercase mb-8"
            data-testid="hero-headline"
          >
            CONQUER THE
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D12828] to-[#F2C94C]">
              WILDERNESS
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="font-exo text-base md:text-lg text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed"
            data-testid="hero-subheadline"
          >
            Unleash your inner racer on rugged off-road tracks, high-octane
            motorsport circuits, and adrenaline-fueled 4x4 adventures. Built for
            those who crave dust, speed, and glory.
          </motion.p>

          {/* CTAs */}
          <motion.div
            variants={fadeUp}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
          >
            <button
              data-testid="hero-book-cta"
              onClick={onBookingOpen}
              className="font-oswald text-base tracking-widest bg-[#D12828] text-white px-10 py-4 btn-skew hover:bg-red-700 transition-all duration-300 animate-pulse-glow"
            >
              <span>BOOK YOUR ADVENTURE</span>
            </button>
            <a
              href="#experiences"
              data-testid="hero-view-experiences-btn"
              className="font-oswald text-sm tracking-widest border border-white/20 text-white px-8 py-4 hover:border-[#F2C94C] hover:text-[#F2C94C] transition-all duration-300 flex items-center gap-3"
            >
              <Play size={16} />
              VIEW EXPERIENCES
            </a>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        data-testid="hero-scroll-indicator"
      >
        <span className="font-oswald text-xs tracking-[0.2em] text-gray-500 uppercase">
          Scroll Down
        </span>
        <ChevronDown size={20} className="text-gray-500 animate-scroll-bounce" />
      </motion.div>
    </section>
  );
}
