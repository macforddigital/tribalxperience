import { motion } from "framer-motion";
import { Calendar, Briefcase, Flag, MapPin } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const events = [
  {
    icon: Calendar,
    title: "CLUB EVENTS",
    desc: "Weekly meetups for car and bike clubs. Bring your crew, hit the tracks, and bond over shared adrenaline.",
    tag: "WEEKLY",
    featured: true,
  },
  {
    icon: Briefcase,
    title: "CORPORATE BOOKINGS",
    desc: "Team building with teeth. Corporate experiences that challenge, unite, and energize your team like nothing else.",
    tag: "PREMIUM",
    featured: false,
  },
  {
    icon: Flag,
    title: "WEEKEND COMPETITIONS",
    desc: "Timed laps, head-to-head battles, and championship rounds. Compete for glory every weekend at Tribal Xperience.",
    tag: "POPULAR",
    featured: true,
  },
  {
    icon: MapPin,
    title: "TOURING GROUPS",
    desc: "Curated adventure routes for touring groups. Multi-day experiences through breathtaking off-road terrain.",
    tag: "NEW",
    featured: false,
  },
];

const EVENT_IMG =
  "https://images.unsplash.com/photo-1762134356679-8bc8f7b367cc?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzV8MHwxfHNlYXJjaHwxfHxvZmYtcm9hZCUyMDR4NCUyMGFkdmVudHVyZSUyMGRpcnQlMjB0cmFja3xlbnwwfHx8fDE3NzE5MjM3MTV8MA&ixlib=rb-4.1.0&q=85";

export default function EventsSection() {
  return (
    <section
      id="events"
      data-testid="events-section"
      className="relative py-20 md:py-32 bg-[#111111] overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
          className="mb-16"
        >
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-4"
          >
            Join The Tribe
          </motion.p>
          <motion.h2
            variants={fadeUp}
            transition={{ duration: 0.6 }}
            className="font-anton text-4xl sm:text-5xl lg:text-6xl uppercase tracking-wide"
          >
            EVENTS & <span className="text-[#D12828]">COMMUNITY</span>
          </motion.h2>
        </motion.div>

        {/* Split Layout */}
        <div className="grid lg:grid-cols-5 gap-8">
          {/* Image side */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeUp}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2 relative"
          >
            <div className="relative h-full min-h-[400px] overflow-hidden">
              <img
                src={EVENT_IMG}
                alt="Event"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#111111]/80 lg:block hidden" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111111] to-transparent lg:hidden" />
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#D12828] to-[#F2C94C]" />
            </div>
          </motion.div>

          {/* Events Grid */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={{
              hidden: { opacity: 0 },
              visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
            }}
            className="lg:col-span-3 grid sm:grid-cols-2 gap-4"
          >
            {events.map((event, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                data-testid={`event-card-${i}`}
                className="group p-6 bg-white/[0.03] border border-white/10 hover:border-[#D12828]/40 transition-all duration-500 glow-border-hover relative"
              >
                {/* Tag */}
                <span
                  className={`absolute top-4 right-4 font-oswald text-[10px] tracking-widest px-2 py-0.5 ${
                    event.featured
                      ? "bg-[#F2C94C] text-black font-semibold"
                      : "border border-white/20 text-gray-500"
                  }`}
                >
                  {event.tag}
                </span>

                <event.icon
                  size={28}
                  className="text-[#D12828] mb-4 group-hover:scale-110 transition-transform duration-300"
                />
                <h3 className="font-anton text-lg tracking-wider mb-2">
                  {event.title}
                </h3>
                <p className="font-exo text-sm text-gray-500 leading-relaxed">
                  {event.desc}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
