import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const navLinks = [
  { label: "ABOUT", href: "#about" },
  { label: "EXPERIENCES", href: "#experiences" },
  { label: "EVENTS", href: "#events" },
  { label: "GALLERY", href: "#gallery" },
  { label: "CONTACT", href: "#contact" },
];

export default function Navbar({ onBookingOpen }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      data-testid="navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/90 backdrop-blur-xl border-b border-white/5"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-20">
        {/* Logo */}
        <a
          href="#hero"
          data-testid="nav-logo"
          className="font-anton text-2xl tracking-wider text-white hover:text-[#D12828] transition-colors"
        >
          TRIBAL <span className="text-[#D12828]">X</span>PERIENCE
        </a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              data-testid={`nav-${link.label.toLowerCase()}-link`}
              className="font-oswald text-sm tracking-widest text-gray-400 hover:text-white transition-colors relative group"
            >
              {link.label}
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#D12828] transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        {/* Book Now Button */}
        <button
          data-testid="nav-book-now-btn"
          onClick={onBookingOpen}
          className="hidden lg:block font-oswald text-sm tracking-widest bg-[#D12828] text-white px-6 py-3 btn-skew hover:bg-red-700 transition-all duration-300 hover:shadow-[0_0_20px_rgba(209,40,40,0.5)]"
        >
          <span>BOOK NOW</span>
        </button>

        {/* Mobile Menu Toggle */}
        <button
          data-testid="nav-mobile-menu-btn"
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden text-white p-2"
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-black/95 backdrop-blur-xl border-t border-white/5 overflow-hidden"
          >
            <div className="px-6 py-6 flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="font-oswald text-sm tracking-widest text-gray-400 hover:text-white transition-colors py-2"
                >
                  {link.label}
                </a>
              ))}
              <button
                onClick={() => {
                  setMobileOpen(false);
                  onBookingOpen();
                }}
                className="font-oswald text-sm tracking-widest bg-[#D12828] text-white px-6 py-3 mt-2 hover:bg-red-700 transition-all"
              >
                BOOK NOW
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
