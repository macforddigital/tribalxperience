import { motion } from "framer-motion";

export default function CTASection({ onBookingOpen }) {
  return (
    <section
      data-testid="cta-section"
      className="relative py-20 md:py-32 bg-[#111111] overflow-hidden"
    >
      {/* Spotlight gradient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-[#D12828]/8 blur-[200px]" />

      {/* Grain */}
      <div className="absolute inset-0 grain-overlay" />

      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className="font-oswald text-sm tracking-[0.3em] text-[#F2C94C] uppercase mb-6">
            Your Turn
          </p>
          <h2 className="font-anton text-4xl sm:text-5xl md:text-6xl lg:text-7xl uppercase tracking-wide mb-8">
            READY TO CONQUER
            <br />
            <span className="text-[#D12828]">THE TRACK?</span>
          </h2>
          <p className="font-exo text-base md:text-lg text-gray-500 max-w-xl mx-auto mb-12 leading-relaxed">
            The dust is calling. The engines are roaring. Whether you're a first-timer
            or a seasoned rider, Tribal Xperience has a track with your name on it.
          </p>
          <button
            data-testid="cta-book-btn"
            onClick={onBookingOpen}
            className="font-oswald text-base tracking-widest bg-[#D12828] text-white px-12 py-5 btn-skew hover:bg-red-700 transition-all duration-300 animate-pulse-glow"
          >
            <span>BOOK YOUR ADVENTURE</span>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
