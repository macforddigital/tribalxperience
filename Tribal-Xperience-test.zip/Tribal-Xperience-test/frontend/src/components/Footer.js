import { motion } from "framer-motion";
import { Instagram, Facebook, Youtube, Twitter, Mail, Phone, MapPin } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const socialLinks = [
  { icon: Instagram, label: "Instagram", href: "#" },
  { icon: Facebook, label: "Facebook", href: "#" },
  { icon: Youtube, label: "YouTube", href: "#" },
  { icon: Twitter, label: "Twitter", href: "#" },
];

const quickLinks = [
  { label: "About Us", href: "#about" },
  { label: "Experiences", href: "#experiences" },
  { label: "Events", href: "#events" },
  { label: "Gallery", href: "#gallery" },
];

const experienceLinks = [
  { label: "Off-Road Tracks", href: "#experiences" },
  { label: "Bike Events", href: "#experiences" },
  { label: "4x4 Experiences", href: "#experiences" },
  { label: "Test Drives", href: "#experiences" },
];

export default function Footer() {
  return (
    <footer
      id="contact"
      data-testid="footer-section"
      className="relative bg-[#0A0A0A] border-t border-white/5"
    >
      {/* Large TRIBAL text */}
      <div className="overflow-hidden py-10 md:py-16">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <h2 className="font-anton text-[80px] sm:text-[120px] md:text-[180px] lg:text-[240px] text-white/[0.03] leading-none tracking-wider text-center select-none whitespace-nowrap">
            TRIBAL
          </h2>
        </motion.div>
      </div>

      {/* Footer Content */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-50px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: { opacity: 1, transition: { staggerChildren: 0.05 } },
        }}
        className="max-w-7xl mx-auto px-6 pb-8"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
            <h3 className="font-anton text-2xl tracking-wider mb-4">
              TRIBAL <span className="text-[#D12828]">X</span>PERIENCE
            </h3>
            <p className="font-exo text-sm text-gray-500 leading-relaxed mb-6">
              South Africa's premier off-road and motorsport adventure venue.
              Where the brave come to play.
            </p>
            {/* Social Icons */}
            <div className="flex gap-3">
              {socialLinks.map((social, i) => (
                <a
                  key={i}
                  href={social.href}
                  data-testid={`footer-social-${social.label.toLowerCase()}`}
                  className="w-10 h-10 flex items-center justify-center border border-white/10 text-gray-500 hover:text-[#F2C94C] hover:border-[#F2C94C]/50 hover:shadow-[0_0_15px_rgba(242,201,76,0.2)] transition-all duration-300"
                >
                  <social.icon size={16} />
                </a>
              ))}
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
            <h4 className="font-oswald text-sm tracking-[0.2em] text-white mb-6 uppercase">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link, i) => (
                <li key={i}>
                  <a
                    href={link.href}
                    className="font-exo text-sm text-gray-500 hover:text-white hover:pl-2 transition-all duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Experiences */}
          <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
            <h4 className="font-oswald text-sm tracking-[0.2em] text-white mb-6 uppercase">
              Experiences
            </h4>
            <ul className="space-y-3">
              {experienceLinks.map((link, i) => (
                <li key={i}>
                  <a
                    href={link.href}
                    className="font-exo text-sm text-gray-500 hover:text-white hover:pl-2 transition-all duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact */}
          <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
            <h4 className="font-oswald text-sm tracking-[0.2em] text-white mb-6 uppercase">
              Contact
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin size={16} className="text-[#D12828] mt-0.5 flex-shrink-0" />
                <span className="font-exo text-sm text-gray-500">
                  Tribal Xperience Venue,
                  <br />
                  Gauteng, South Africa
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-[#D12828] flex-shrink-0" />
                <span className="font-exo text-sm text-gray-500">
                  +27 (0) 82 123 4567
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={16} className="text-[#D12828] flex-shrink-0" />
                <span className="font-exo text-sm text-gray-500">
                  info@tribalxperience.co.za
                </span>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/5 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-exo text-xs text-gray-600">
            &copy; {new Date().getFullYear()} Tribal Xperience. All Rights Reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="font-exo text-xs text-gray-600 hover:text-white transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="font-exo text-xs text-gray-600 hover:text-white transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </motion.div>
    </footer>
  );
}
