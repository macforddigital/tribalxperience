import { useState } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "sonner";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ExperiencesSection from "@/components/ExperiencesSection";
import EventsSection from "@/components/EventsSection";
import StatsSection from "@/components/StatsSection";
import GallerySection from "@/components/GallerySection";
import TestimonialsSection from "@/components/TestimonialsSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import BookingModal from "@/components/BookingModal";

function HomePage({ onBookingOpen }) {
  return (
    <>
      <HeroSection onBookingOpen={onBookingOpen} />
      <AboutSection />
      <ExperiencesSection />
      <EventsSection />
      <StatsSection />
      <GallerySection />
      <TestimonialsSection />
      <CTASection onBookingOpen={onBookingOpen} />
    </>
  );
}

function App() {
  const [bookingOpen, setBookingOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#111111] text-white overflow-x-hidden">
      <BrowserRouter>
        <Navbar onBookingOpen={() => setBookingOpen(true)} />
        <Routes>
          <Route
            path="/"
            element={<HomePage onBookingOpen={() => setBookingOpen(true)} />}
          />
        </Routes>
        <Footer />
        <BookingModal open={bookingOpen} onOpenChange={setBookingOpen} />
        <Toaster
          theme="dark"
          position="top-right"
          toastOptions={{
            style: {
              background: '#1A1A1A',
              border: '1px solid rgba(255,255,255,0.1)',
              color: '#fff',
            },
          }}
        />
      </BrowserRouter>
    </div>
  );
}

export default App;
